//Masquer ou afficher les commentaires

function toggleVisibility(){
    let toogleBloc = document.getElementById("toggle-bloc");
    if(toogleBloc.style.display ==="none"){
        toogleBloc.style.display="block";
    }else{
    toogleBloc.style.display="none";
    }
}
